//
//  ViewController.h
//  openGLESGLKit06
//
//  Created by 刘晓亮 on 2017/8/23.
//  Copyright © 2017年 刘晓亮. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>

@interface ViewController : GLKViewController


@end

