//
//  AppDelegate.h
//  learnOpenGLESGLKit03
//
//  Created by 刘晓亮 on 2017/8/17.
//  Copyright © 2017年 刘晓亮. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

