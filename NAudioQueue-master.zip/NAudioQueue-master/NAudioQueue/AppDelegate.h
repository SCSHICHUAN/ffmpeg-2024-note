//
//  AppDelegate.h
//  NAudioQueue
//
//  Created by 泽娄 on 2019/9/20.
//  Copyright © 2019 泽娄. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

